from django.contrib import admin
from .models import *

admin.site.register(answerOption)
admin.site.register(question)
admin.site.register(form)
admin.site.register(Profile)
admin.site.register(userAnswer)
admin.site.register(userReview)

